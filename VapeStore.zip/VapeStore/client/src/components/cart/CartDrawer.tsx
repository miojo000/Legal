import { useEffect } from "react";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ShoppingCart, X, Plus, Minus, Trash2 } from "lucide-react";
import { useLocation } from "wouter";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

const CartDrawer = ({ isOpen, onClose }: CartDrawerProps) => {
  const { cart, removeFromCart, updateCartItemQuantity, total } = useCart();
  const [, navigate] = useLocation();

  // Handle Checkout button
  const handleCheckout = () => {
    onClose();
    navigate("/checkout");
  };

  // Handle Continue Shopping button
  const handleContinueShopping = () => {
    onClose();
  };

  // Close drawer when ESC key is pressed
  useEffect(() => {
    const handleEscKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" && isOpen) {
        onClose();
      }
    };

    window.addEventListener("keydown", handleEscKey);
    
    // Prevent scrolling when drawer is open
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }

    return () => {
      window.removeEventListener("keydown", handleEscKey);
      document.body.style.overflow = "";
    };
  }, [isOpen, onClose]);

  return (
    <>
      {/* Overlay */}
      <div 
        className={`fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />
      
      {/* Cart Drawer */}
      <div 
        className={`fixed top-0 right-0 h-full w-full md:w-96 bg-white shadow-xl transform transition-transform ease-in-out duration-300 z-50 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
      >
        <div className="h-full flex flex-col">
          {/* Cart Header */}
          <div className="p-4 border-b border-gray-200 flex justify-between items-center">
            <h3 className="font-semibold text-xl">Seu Carrinho</h3>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-gray-500 hover:text-purple-600">
              <X size={20} />
            </Button>
          </div>
          
          {/* Cart Items */}
          <div className="flex-grow overflow-y-auto py-4 px-6">
            {cart.length === 0 ? (
              <div className="text-center py-8">
                <div className="text-gray-400 mb-4">
                  <ShoppingCart className="mx-auto h-12 w-12" />
                </div>
                <h4 className="font-medium text-xl mb-2">Seu carrinho está vazio</h4>
                <p className="text-gray-500 mb-4">Adicione produtos para continuar</p>
                <Button 
                  onClick={handleContinueShopping}
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                >
                  Continuar comprando
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {cart.map((item) => (
                  <div key={item.id} className="flex items-center border-b border-gray-200 pb-4">
                    <img 
                      src={item.image} 
                      alt={item.name} 
                      className="w-16 h-16 object-cover rounded-md"
                    />
                    <div className="ml-4 flex-grow">
                      <h5 className="font-medium">{item.name}</h5>
                      <div className="flex justify-between items-center mt-1">
                        <div className="flex items-center">
                          <Button 
                            variant="outline" 
                            size="icon" 
                            className="h-5 w-5 rounded-full p-0"
                            onClick={() => updateCartItemQuantity(item.id, Math.max(1, item.quantity - 1))}
                            disabled={item.quantity <= 1}
                          >
                            <Minus size={12} />
                          </Button>
                          <span className="mx-2 text-sm">{item.quantity}</span>
                          <Button 
                            variant="outline" 
                            size="icon" 
                            className="h-5 w-5 rounded-full p-0"
                            onClick={() => updateCartItemQuantity(item.id, item.quantity + 1)}
                          >
                            <Plus size={12} />
                          </Button>
                        </div>
                        <span className="font-semibold">
                          R${(item.price * item.quantity).toFixed(2).replace('.', ',')}
                        </span>
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="ml-2 text-gray-400 hover:text-red-500"
                      onClick={() => removeFromCart(item.id)}
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {/* Cart Footer */}
          <div className="p-4 border-t border-gray-200">
            <div className="mb-4 flex justify-between">
              <span className="font-medium">Subtotal</span>
              <span className="font-bold">R${total.toFixed(2).replace('.', ',')}</span>
            </div>
            <Button 
              onClick={handleCheckout}
              className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold w-full py-3"
              disabled={cart.length === 0}
            >
              Finalizar compra
            </Button>
            <Button 
              onClick={handleContinueShopping}
              variant="ghost" 
              className="text-purple-600 hover:text-purple-700 font-medium w-full py-2 mt-2"
            >
              Continuar comprando
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default CartDrawer;
