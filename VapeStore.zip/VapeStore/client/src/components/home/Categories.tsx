import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";

interface Category {
  id: number;
  name: string;
  slug: string;
  icon: string;
}

const Categories = () => {
  const [, navigate] = useLocation();
  
  const { data: categories, isLoading } = useQuery({
    queryKey: ['/api/categories'],
    queryFn: async () => {
      const response = await fetch('/api/categories');
      if (!response.ok) {
        throw new Error('Failed to fetch categories');
      }
      return response.json();
    }
  });

  const handleCategoryClick = (slug: string) => {
    navigate(`/?categories=${slug}`);
  };

  // Icon mapping for Font Awesome icons
  const getIconClass = (iconName: string) => {
    return iconName;
  };

  return (
    <section id="categories" className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">Categorias em destaque</h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {isLoading ? (
            // Loading skeletons
            Array(4).fill(0).map((_, index) => (
              <div key={index} className="bg-gray-100 rounded-lg p-6 text-center">
                <Skeleton className="w-16 h-16 rounded-full mx-auto mb-4" />
                <Skeleton className="h-5 w-3/4 mx-auto mb-2" />
                <Skeleton className="h-4 w-1/2 mx-auto" />
              </div>
            ))
          ) : (
            // Actual categories
            categories && categories.map((category: Category) => (
              <div 
                key={category.id}
                className="group cursor-pointer" 
                onClick={() => handleCategoryClick(category.slug)}
              >
                <div className="bg-gray-100 rounded-lg p-6 text-center transition-all hover:shadow-md">
                  <div className="w-16 h-16 bg-purple-400 rounded-full flex items-center justify-center mx-auto mb-4 text-white">
                    <i className={getIconClass(category.icon)}></i>
                  </div>
                  <h3 className="font-semibold text-lg mb-1">{category.name}</h3>
                  <p className="text-sm text-gray-500">A partir de R$50</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default Categories;
