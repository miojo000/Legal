import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Phone, Mail, Clock, Facebook, Instagram, Twitter } from "lucide-react";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setIsSubmitting(true);
      // Here you would normally submit to an API
      // Simulating API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Mensagem enviada!",
        description: "Agradecemos seu contato. Responderemos em breve.",
      });
      
      setFormData({
        name: "",
        email: "",
        subject: "",
        message: ""
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao enviar sua mensagem. Tente novamente mais tarde.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold mb-12 text-center">Entre em contato</h2>
          
          <div className="flex flex-col md:flex-row gap-8">
            {/* Contact Information */}
            <div className="md:w-1/3">
              <div className="bg-gray-100 p-6 rounded-lg h-full">
                <h3 className="font-semibold text-xl mb-4">Informações</h3>
                
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="bg-purple-400 rounded-full w-10 h-10 flex items-center justify-center text-white flex-shrink-0 mt-1">
                      <MapPin size={18} />
                    </div>
                    <div className="ml-4">
                      <h4 className="font-medium">Endereço</h4>
                      <p className="text-gray-600">Av. Paulista, 1000, São Paulo - SP</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-purple-400 rounded-full w-10 h-10 flex items-center justify-center text-white flex-shrink-0 mt-1">
                      <Phone size={18} />
                    </div>
                    <div className="ml-4">
                      <h4 className="font-medium">Telefone</h4>
                      <p className="text-gray-600">(11) 99999-9999</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-purple-400 rounded-full w-10 h-10 flex items-center justify-center text-white flex-shrink-0 mt-1">
                      <Mail size={18} />
                    </div>
                    <div className="ml-4">
                      <h4 className="font-medium">Email</h4>
                      <p className="text-gray-600">contato@vapebr.com.br</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-purple-400 rounded-full w-10 h-10 flex items-center justify-center text-white flex-shrink-0 mt-1">
                      <Clock size={18} />
                    </div>
                    <div className="ml-4">
                      <h4 className="font-medium">Horário</h4>
                      <p className="text-gray-600">Seg-Sex: 9h às 18h</p>
                      <p className="text-gray-600">Sáb: 9h às 13h</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <h4 className="font-medium mb-2">Siga-nos</h4>
                  <div className="flex space-x-4">
                    <a href="#" className="bg-purple-600 hover:bg-purple-700 text-white w-8 h-8 rounded-full flex items-center justify-center transition-colors">
                      <Facebook size={16} />
                    </a>
                    <a href="#" className="bg-purple-600 hover:bg-purple-700 text-white w-8 h-8 rounded-full flex items-center justify-center transition-colors">
                      <Instagram size={16} />
                    </a>
                    <a href="#" className="bg-purple-600 hover:bg-purple-700 text-white w-8 h-8 rounded-full flex items-center justify-center transition-colors">
                      <Twitter size={16} />
                    </a>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Contact Form */}
            <div className="md:w-2/3">
              <form onSubmit={handleSubmit} className="bg-gray-100 p-6 rounded-lg">
                <h3 className="font-semibold text-xl mb-4">Envie uma mensagem</h3>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Nome</label>
                    <Input 
                      id="name" 
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-2 rounded-md"
                      required
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <Input 
                      id="email" 
                      name="email"
                      type="email" 
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full px-4 py-2 rounded-md"
                      required
                    />
                  </div>
                </div>
                
                <div className="mb-4">
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">Assunto</label>
                  <Input 
                    id="subject" 
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className="w-full px-4 py-2 rounded-md"
                    required
                  />
                </div>
                
                <div className="mb-4">
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Mensagem</label>
                  <Textarea 
                    id="message" 
                    name="message"
                    rows={5} 
                    value={formData.message}
                    onChange={handleChange}
                    className="w-full px-4 py-2 rounded-md"
                    required
                  />
                </div>
                
                <Button 
                  type="submit"
                  className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-6 rounded-md"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Enviando..." : "Enviar mensagem"}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
