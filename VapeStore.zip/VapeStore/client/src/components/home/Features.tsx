import { Truck, Shield, Headphones } from "lucide-react";

const Features = () => {
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-12 text-center">Por que escolher a VapeBR?</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-purple-400 rounded-full flex items-center justify-center text-white mb-4">
              <Truck size={24} />
            </div>
            <h3 className="font-semibold text-xl mb-2">Entrega Rápida</h3>
            <p className="text-gray-600">Envio para todo o Brasil com opções de frete expresso.</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-purple-400 rounded-full flex items-center justify-center text-white mb-4">
              <Shield size={24} />
            </div>
            <h3 className="font-semibold text-xl mb-2">Produtos Autênticos</h3>
            <p className="text-gray-600">Garantia de produtos originais e de alta qualidade.</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-purple-400 rounded-full flex items-center justify-center text-white mb-4">
              <Headphones size={24} />
            </div>
            <h3 className="font-semibold text-xl mb-2">Suporte Dedicado</h3>
            <p className="text-gray-600">Atendimento especializado para ajudar na sua escolha.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
