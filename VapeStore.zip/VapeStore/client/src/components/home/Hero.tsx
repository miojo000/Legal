import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

const Hero = () => {
  const [, navigate] = useLocation();
  
  return (
    <section className="bg-gradient-to-r from-purple-600 to-violet-900 text-white py-12 md:py-24">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Encontre o melhor vape para você
            </h1>
            <p className="text-lg mb-6 text-gray-100">
              Variedade de produtos de alta qualidade por preços acessíveis, entre R$50 e R$80.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button 
                onClick={() => navigate("/#products")}
                className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 px-6 rounded-full text-lg"
                size="lg"
              >
                Ver nosso CATÁLOGO COMPLETO
              </Button>
              <Button 
                onClick={() => navigate("/#categories")}
                variant="outline"
                className="bg-white hover:bg-gray-200 text-purple-600 font-bold py-3 px-6 rounded-full"
              >
                Categorias
              </Button>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center md:justify-end">
            <img 
              src="https://images.unsplash.com/photo-1560373052-084db4239c40?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" 
              alt="Vape device showcase" 
              className="rounded-lg shadow-2xl w-full max-w-md"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
