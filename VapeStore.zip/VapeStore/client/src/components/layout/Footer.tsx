import { Link } from "wouter";
import { MapPin, Phone, Mail, Clock, Facebook, Instagram, Twitter, Youtube } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About Column */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Sobre nós</h4>
            <p className="text-gray-300 mb-4">
              A VapeBR é a maior loja especializada em produtos para vape no Brasil, 
              oferecendo produtos de qualidade com preços acessíveis.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Instagram size={18} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Twitter size={18} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Youtube size={18} />
              </a>
            </div>
          </div>
          
          {/* Categories Column */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Categorias</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/?categories=descartaveis" className="text-gray-300 hover:text-white transition-colors">Descartáveis</Link>
              </li>
              <li>
                <Link href="/?categories=pod-systems" className="text-gray-300 hover:text-white transition-colors">Pod Systems</Link>
              </li>
              <li>
                <Link href="/?categories=e-liquids" className="text-gray-300 hover:text-white transition-colors">E-liquids</Link>
              </li>
              <li>
                <Link href="/?categories=acessorios" className="text-gray-300 hover:text-white transition-colors">Acessórios</Link>
              </li>
              <li>
                <Link href="/?categories=bobinas" className="text-gray-300 hover:text-white transition-colors">Bobinas</Link>
              </li>
            </ul>
          </div>
          
          {/* Information Column */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Informações</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">Sobre nós</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">Envio e entrega</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">Política de privacidade</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">Termos e condições</a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">Dúvidas frequentes</a>
              </li>
            </ul>
          </div>
          
          {/* Contact Column */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Contato</h4>
            <ul className="space-y-2">
              <li className="flex items-start">
                <MapPin className="mt-1 mr-2 text-emerald-500" size={16} />
                <span>Av. Paulista, 1000, São Paulo - SP</span>
              </li>
              <li className="flex items-start">
                <Phone className="mt-1 mr-2 text-emerald-500" size={16} />
                <span>(11) 99999-9999</span>
              </li>
              <li className="flex items-start">
                <Mail className="mt-1 mr-2 text-emerald-500" size={16} />
                <span>contato@vapebr.com.br</span>
              </li>
              <li className="flex items-start">
                <Clock className="mt-1 mr-2 text-emerald-500" size={16} />
                <span>Seg-Sex: 9h às 18h</span>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Footer Bottom */}
        <div className="border-t border-gray-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 mb-4 md:mb-0">
            © {new Date().getFullYear()} VapeBR. Todos os direitos reservados.
          </p>
          <div className="flex space-x-4">
            <span className="text-xs text-gray-400">Formas de pagamento</span>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8" viewBox="0 0 556 138" fill="none">
              <path d="M87.6 89.9H66.8L80.1 35.7H101L87.6 89.9ZM109.2 35.8L87.4 107.6C86.9 109.1 85.6 110 83.9 110H61.3L52.6 79.6L36.1 110H14.5L44.6 36.6H66.2L59.4 59.6L71.5 35.8H93.1L96.7 61.6L109.2 35.8ZM195.2 35.8H217.3L202.3 110H180.2L195.2 35.8ZM157.5 35.8L142.5 110H120.4L135.4 35.8H157.5ZM174.8 73.2L189.9 35.8H166.4L158.4 54.8L163.1 35.8H141L126 110H148.1L154.9 73.2H174.8ZM420.5 93.4C413.2 93.4 407.2 86.7 407.2 78.4C407.2 70.1 413.1 63.4 420.5 63.4C427.9 63.4 433.8 70.1 433.8 78.4C433.8 86.7 427.9 93.4 420.5 93.4ZM420.5 56.1C408.7 56.1 399.2 66.1 399.2 78.4C399.2 90.7 408.8 100.7 420.5 100.7C432.3 100.7 441.8 90.7 441.8 78.4C441.8 66.1 432.3 56.1 420.5 56.1ZM461.6 56.1C449.8 56.1 440.3 66.1 440.3 78.4C440.3 90.7 449.9 100.7 461.6 100.7C473.4 100.7 482.9 90.7 482.9 78.4C482.9 66.1 473.4 56.1 461.6 56.1ZM461.6 93.4C454.3 93.4 448.3 86.7 448.3 78.4C448.3 70.1 454.2 63.4 461.6 63.4C469 63.4 474.9 70.1 474.9 78.4C474.9 86.7 469 93.4 461.6 93.4ZM515.5 56.1C503.7 56.1 494.2 66.1 494.2 78.4C494.2 90.7 503.8 100.7 515.5 100.7C527.3 100.7 536.8 90.7 536.8 78.4C536.8 66.1 527.3 56.1 515.5 56.1ZM515.5 93.4C508.2 93.4 502.2 86.7 502.2 78.4C502.2 70.1 508.1 63.4 515.5 63.4C522.9 63.4 528.8 70.1 528.8 78.4C528.8 86.7 522.9 93.4 515.5 93.4ZM351.2 56.1C339.4 56.1 329.9 66.1 329.9 78.4C329.9 90.7 339.5 100.7 351.2 100.7C363 100.7 372.5 90.7 372.5 78.4C372.5 66.1 363 56.1 351.2 56.1ZM351.2 93.4C343.9 93.4 337.9 86.7 337.9 78.4C337.9 70.1 343.8 63.4 351.2 63.4C358.6 63.4 364.5 70.1 364.5 78.4C364.5 86.7 358.6 93.4 351.2 93.4ZM296.6 100H304.7V57H296.6V100ZM328.3 57H320.3V100H328.3V74.2C328.3 67.6 332.9 63.1 339.4 63.1C340.1 63.1 340.8 63.2 341.5 63.3V56.9C341 56.8 340.5 56.8 340 56.8C334.5 56.8 330.1 60.5 328.3 65.7V57ZM296.6 45.8C296.6 48.4 298.7 50.4 301.2 50.4C303.8 50.4 305.8 48.3 305.8 45.8C305.8 43.2 303.7 41.2 301.2 41.2C298.6 41.2 296.6 43.3 296.6 45.8ZM373.2 57H381.2V100H373.2V57ZM373.2 45.8C373.2 48.4 375.3 50.4 377.8 50.4C380.4 50.4 382.4 48.3 382.4 45.8C382.4 43.2 380.3 41.2 377.8 41.2C375.2 41.2 373.2 43.3 373.2 45.8ZM254.9 36.9C245.5 36.9 237.3 39.7 230.6 44.9L234.6 52.3C239.8 48.1 246.8 45.8 254.1 45.8C267 45.8 274.6 53.3 274.6 65.9V69.1C268.5 65.7 261.5 64 253.8 64C237.2 64 226.7 72.3 226.7 84.8V85.2C226.7 97.2 237.2 105.1 251.2 105.1C261.2 105.1 269.2 101.3 274.4 94.5V103.2H283.1V66.2C283.1 48.3 272.1 36.9 254.9 36.9ZM252.5 97.1C242.6 97.1 235.3 92.1 235.3 84.9V84.5C235.3 76.6 242.8 71.4 254.7 71.4C262.3 71.4 268.7 73.1 274.4 76.6V83.5C274.4 91.6 265 97.1 252.5 97.1Z" fill="#828282"/>
            </svg>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
