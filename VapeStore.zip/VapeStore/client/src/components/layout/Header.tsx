import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import CartDrawer from "@/components/cart/CartDrawer";
import { ShoppingCart, Search, Menu, X } from "lucide-react";
import { useMobile } from "@/hooks/use-mobile";

const Header = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { cart } = useCart();
  const [, navigate] = useLocation();
  const isMobile = useMobile();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/?search=${encodeURIComponent(searchQuery)}`);
      setSearchQuery("");
      if (isMobileMenuOpen) setIsMobileMenuOpen(false);
    }
  };

  // Close mobile menu when screen size changes
  useEffect(() => {
    if (!isMobile && isMobileMenuOpen) {
      setIsMobileMenuOpen(false);
    }
  }, [isMobile, isMobileMenuOpen]);

  const cartItemsCount = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <>
      <header className="bg-white shadow-md sticky top-0 z-40">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link href="/" className="flex items-center">
                <span className="text-purple-600 font-bold text-2xl">Vape<span className="text-emerald-500">BR</span></span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className="font-medium hover:text-purple-600 transition-colors">Home</Link>
              <Link href="/#products" className="font-medium hover:text-purple-600 transition-colors">Produtos</Link>
              <Link href="/#categories" className="font-medium hover:text-purple-600 transition-colors">Categorias</Link>
              <Link href="/#contact" className="font-medium hover:text-purple-600 transition-colors">Contato</Link>
            </nav>

            {/* Search, Cart, Menu */}
            <div className="flex items-center space-x-4">
              {/* Desktop Search */}
              <form onSubmit={handleSearch} className="hidden md:flex items-center bg-gray-100 rounded-full px-3 py-1">
                <Input
                  type="text"
                  placeholder="Buscar produtos..."
                  className="bg-transparent border-0 w-48 h-8 focus-visible:ring-0 focus-visible:ring-offset-0"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Button type="submit" variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-purple-600">
                  <Search size={16} />
                </Button>
              </form>

              {/* Cart */}
              <div className="relative">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setIsCartOpen(true)}
                  className="relative text-gray-800 hover:text-purple-600 transition-colors"
                >
                  <ShoppingCart size={20} />
                  {cartItemsCount > 0 && (
                    <span className="cart-badge bg-emerald-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      {cartItemsCount}
                    </span>
                  )}
                </Button>
              </div>

              {/* Mobile Menu Toggle */}
              <Button 
                variant="ghost" 
                size="icon" 
                className="md:hidden text-gray-800 hover:text-purple-600 transition-colors"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
              </Button>
            </div>
          </div>

          {/* Mobile Navigation & Search (Hidden by Default) */}
          {isMobileMenuOpen && (
            <div className="md:hidden pt-4 pb-3">
              <nav className="flex flex-col space-y-2">
                <Link href="/" className="px-3 py-2 rounded-md text-base font-medium hover:bg-gray-100" onClick={() => setIsMobileMenuOpen(false)}>Home</Link>
                <Link href="/#products" className="px-3 py-2 rounded-md text-base font-medium hover:bg-gray-100" onClick={() => setIsMobileMenuOpen(false)}>Produtos</Link>
                <Link href="/#categories" className="px-3 py-2 rounded-md text-base font-medium hover:bg-gray-100" onClick={() => setIsMobileMenuOpen(false)}>Categorias</Link>
                <Link href="/#contact" className="px-3 py-2 rounded-md text-base font-medium hover:bg-gray-100" onClick={() => setIsMobileMenuOpen(false)}>Contato</Link>
              </nav>
              <form onSubmit={handleSearch} className="mt-3">
                <div className="relative flex items-center bg-gray-100 rounded-full px-3 py-1">
                  <Input
                    type="text"
                    placeholder="Buscar produtos..."
                    className="bg-transparent border-0 h-10 focus-visible:ring-0 focus-visible:ring-offset-0"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <Button type="submit" variant="ghost" size="icon" className="absolute right-2 h-8 w-8 text-gray-500 hover:text-purple-600">
                    <Search size={16} />
                  </Button>
                </div>
              </form>
            </div>
          )}
        </div>
      </header>

      {/* Cart Drawer */}
      <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </>
  );
};

export default Header;
