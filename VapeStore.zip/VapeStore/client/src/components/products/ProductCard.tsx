import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Star, Plus, CheckCircle, XCircle } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

interface ProductCardProps {
  product: {
    id: number;
    slug: string;
    name: string;
    description: string;
    image: string;
    price: string | number;
    inStock: boolean;
    rating: string | number;
    reviewCount: number;
    badge?: string | null;
  };
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { addToCart } = useCart();
  const { toast } = useToast();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!product.inStock) return;
    
    addToCart({
      id: product.id,
      name: product.name,
      image: product.image,
      price: typeof product.price === 'string' ? parseFloat(product.price) : product.price,
      quantity: 1
    });
    
    toast({
      title: "Produto adicionado",
      description: `${product.name} foi adicionado ao carrinho`,
      duration: 3000,
    });
  };

  // Format price from either string or number
  const formattedPrice = typeof product.price === 'string' 
    ? `R$${parseFloat(product.price).toFixed(2).replace('.', ',')}`
    : `R$${product.price.toFixed(2).replace('.', ',')}`;

  // Convert rating to number for star display
  const ratingValue = typeof product.rating === 'string' 
    ? parseFloat(product.rating)
    : product.rating;

  return (
    <Link href={`/product/${product.slug}`} className="product-card bg-white rounded-lg shadow-sm overflow-hidden transition-shadow hover:shadow-md block">
        <div className="relative">
          <img 
            src={product.image} 
            alt={product.name} 
            className="w-full h-48 object-cover"
          />
          {product.badge && (
            <Badge 
              className={`absolute top-2 right-2 ${
                product.badge === 'Novo' ? 'bg-purple-600' : 
                product.badge === 'Popular' ? 'bg-yellow-500' : 
                product.badge === 'Promoção' ? 'bg-red-500' : 
                'bg-purple-600'
              }`}
            >
              {product.badge}
            </Badge>
          )}
          <div className="absolute bottom-0 left-0 right-0 p-2 flex gap-2">
            <Button 
              onClick={handleAddToCart}
              disabled={!product.inStock}
              className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white py-2 font-medium text-sm"
              size="sm"
            >
              Comprar Agora
            </Button>
            <Button 
              onClick={handleAddToCart}
              disabled={!product.inStock}
              className="bg-purple-600 hover:bg-purple-700 text-white w-10 h-8 flex items-center justify-center shadow-md"
              size="icon"
              variant="default"
            >
              <Plus size={16} />
            </Button>
          </div>
        </div>
        <div className="p-4">
          <div className="flex justify-between items-start mb-1">
            <h3 className="font-semibold">{product.name}</h3>
            <span className="text-emerald-500 font-bold">{formattedPrice}</span>
          </div>
          <p className="text-gray-600 text-sm mb-2">{product.description}</p>
          <div className="flex justify-between items-center">
            <span className={`text-sm flex items-center ${product.inStock ? 'text-emerald-500' : 'text-red-500'}`}>
              {product.inStock ? (
                <>
                  <CheckCircle size={14} className="mr-1" />
                  Em estoque
                </>
              ) : (
                <>
                  <XCircle size={14} className="mr-1" />
                  Esgotado
                </>
              )}
            </span>
            <div className="flex items-center">
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    size={14}
                    className={i < Math.floor(ratingValue) ? 'fill-current' : 'fill-none'}
                  />
                ))}
              </div>
              <span className="text-xs text-gray-500 ml-1">({product.reviewCount})</span>
            </div>
          </div>
        </div>
    </Link>
  );
};

export default ProductCard;
