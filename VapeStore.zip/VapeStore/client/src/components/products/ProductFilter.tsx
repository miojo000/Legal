import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

interface ProductFilterProps {
  priceValue: number;
  onPriceChange: (value: number) => void;
  selectedCategories: string[];
  onCategoryChange: (categories: string[]) => void;
  inStockOnly: boolean;
  onInStockChange: (value: boolean) => void;
}

const ProductFilter = ({
  priceValue,
  onPriceChange,
  selectedCategories,
  onCategoryChange,
  inStockOnly,
  onInStockChange
}: ProductFilterProps) => {
  const [localPrice, setLocalPrice] = useState<number>(priceValue);
  const [localCategories, setLocalCategories] = useState<string[]>(selectedCategories);
  const [localInStock, setLocalInStock] = useState<boolean>(inStockOnly);

  // Fetch categories for the filter
  const { data: categories, isLoading: loadingCategories } = useQuery({
    queryKey: ['/api/categories'],
    queryFn: async () => {
      const response = await fetch('/api/categories');
      if (!response.ok) {
        throw new Error('Failed to fetch categories');
      }
      return response.json();
    }
  });

  // Apply filters when Apply button is clicked
  const applyFilters = () => {
    onPriceChange(localPrice);
    onCategoryChange(localCategories);
    onInStockChange(localInStock);
  };

  const handleCategoryChange = (category: string, checked: boolean) => {
    if (checked) {
      setLocalCategories([...localCategories, category]);
    } else {
      setLocalCategories(localCategories.filter(c => c !== category));
    }
  };

  // Keep local state in sync with props when they change externally
  useEffect(() => {
    setLocalPrice(priceValue);
  }, [priceValue]);

  useEffect(() => {
    setLocalCategories(selectedCategories);
  }, [selectedCategories]);

  useEffect(() => {
    setLocalInStock(inStockOnly);
  }, [inStockOnly]);

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <h3 className="font-semibold text-lg mb-4">Filtros</h3>
      
      {/* Price Range */}
      <div className="mb-6">
        <h4 className="font-medium text-sm mb-2">Preço</h4>
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">R$50</span>
          <span className="text-sm text-gray-600">R$80</span>
        </div>
        <Slider
          min={50}
          max={80}
          step={1}
          value={[localPrice]}
          onValueChange={(value) => setLocalPrice(value[0])}
          className="my-2"
        />
        <div className="text-center mt-2">
          <span className="text-sm font-medium">até R${localPrice}</span>
        </div>
      </div>
      
      {/* Categories */}
      <div className="mb-6">
        <h4 className="font-medium text-sm mb-2">Categorias</h4>
        <div className="space-y-2">
          {loadingCategories ? (
            <>
              <Skeleton className="h-5 w-full mb-2" />
              <Skeleton className="h-5 w-full mb-2" />
              <Skeleton className="h-5 w-full mb-2" />
              <Skeleton className="h-5 w-full" />
            </>
          ) : (
            categories && categories.map((category: { id: number; slug: string; name: string }) => (
              <div key={category.id} className="flex items-center">
                <Checkbox 
                  id={`category-${category.slug}`}
                  checked={localCategories.includes(category.slug)}
                  onCheckedChange={(checked) => handleCategoryChange(category.slug, checked as boolean)}
                  className="mr-2"
                />
                <Label htmlFor={`category-${category.slug}`} className="text-sm">
                  {category.name}
                </Label>
              </div>
            ))
          )}
        </div>
      </div>
      
      {/* Availability */}
      <div className="mb-4">
        <h4 className="font-medium text-sm mb-2">Disponibilidade</h4>
        <div className="flex items-center">
          <Checkbox 
            id="in-stock"
            checked={localInStock}
            onCheckedChange={(checked) => setLocalInStock(!!checked)}
            className="mr-2"
          />
          <Label htmlFor="in-stock" className="text-sm">
            Em estoque
          </Label>
        </div>
      </div>
      
      {/* Apply Filters Button */}
      <Button 
        onClick={applyFilters}
        className="w-full bg-purple-600 hover:bg-purple-700 text-white"
      >
        Aplicar filtros
      </Button>
    </div>
  );
};

export default ProductFilter;
