import Hero from "@/components/home/Hero";
import Categories from "@/components/home/Categories";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import ProductFilter from "@/components/products/ProductFilter";
import ProductCard from "@/components/products/ProductCard";
import Features from "@/components/home/Features";
import Newsletter from "@/components/home/Newsletter";
import Contact from "@/components/home/Contact";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { Skeleton } from "@/components/ui/skeleton";
import type { Product } from "@shared/schema";

const Home = () => {
  const [priceFilter, setPriceFilter] = useState<number>(80);
  const [categoryFilter, setCategoryFilter] = useState<string[]>([]);
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState<number>(1);
  
  // Fetch products with filters
  const { data: products, isLoading } = useQuery({
    queryKey: ['/api/products', priceFilter, categoryFilter, inStockOnly, currentPage],
    queryFn: async () => {
      const params = new URLSearchParams();
      params.append('maxPrice', priceFilter.toString());
      if (categoryFilter.length > 0) {
        categoryFilter.forEach(cat => params.append('categories', cat));
      }
      if (inStockOnly) {
        params.append('inStock', 'true');
      }
      params.append('page', currentPage.toString());
      
      const response = await fetch(`/api/products?${params.toString()}`);
      if (!response.ok) {
        throw new Error('Failed to fetch products');
      }
      return response.json();
    }
  });

  return (
    <div>
      <Hero />
      
      {/* Spotlight Banner */}
      <section className="py-8 bg-gradient-to-r from-emerald-500 to-emerald-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">CATÁLOGO COMPLETO DE VAPES</h2>
          <p className="text-xl mb-6">Preços entre R$50 e R$80 - As melhores opções do mercado!</p>
          <a href="/#products" className="inline-block bg-white text-emerald-600 font-bold py-3 px-8 rounded-full text-lg hover:bg-gray-100 transition-colors">
            VER TODOS OS VAPES AGORA!  →
          </a>
        </div>
      </section>
      
      <Categories />
      
      {/* Products Section */}
      <section id="products" className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="font-bold text-3xl mb-2 text-center">Nossos Produtos</h2>
          <p className="text-center text-gray-600 mb-8">Encontre o vape perfeito para você</p>
          
          <div className="flex flex-col md:flex-row">
            {/* Filters Sidebar */}
            <div className="w-full md:w-1/4 mb-6 md:mb-0 md:pr-8">
              <ProductFilter 
                priceValue={priceFilter}
                onPriceChange={setPriceFilter}
                selectedCategories={categoryFilter}
                onCategoryChange={setCategoryFilter}
                inStockOnly={inStockOnly}
                onInStockChange={setInStockOnly}
              />
            </div>
            
            {/* Products Grid */}
            <div className="w-full md:w-3/4">
              {isLoading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {Array(6).fill(0).map((_, index) => (
                    <div key={index} className="bg-white rounded-lg shadow-sm overflow-hidden">
                      <Skeleton className="w-full h-48" />
                      <div className="p-4">
                        <Skeleton className="h-6 w-3/4 mb-2" />
                        <Skeleton className="h-4 w-full mb-4" />
                        <div className="flex justify-between">
                          <Skeleton className="h-4 w-1/4" />
                          <Skeleton className="h-4 w-1/4" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {products && products.items && products.items.map((product: Product) => (
                      <ProductCard key={product.id} product={product} />
                    ))}
                  </div>
                  
                  {/* Pagination */}
                  {products && products.totalPages > 1 && (
                    <div className="mt-8 flex justify-center">
                      <Pagination>
                        <PaginationContent>
                          <PaginationItem>
                            <PaginationPrevious 
                              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                              className={currentPage === 1 ? "pointer-events-none opacity-50" : ""}
                            />
                          </PaginationItem>
                          
                          {Array.from({ length: products.totalPages }, (_, i) => i + 1).map((page) => (
                            <PaginationItem key={page}>
                              <PaginationLink 
                                isActive={currentPage === page}
                                onClick={() => setCurrentPage(page)}
                              >
                                {page}
                              </PaginationLink>
                            </PaginationItem>
                          ))}
                          
                          <PaginationItem>
                            <PaginationNext 
                              onClick={() => setCurrentPage(prev => Math.min(products.totalPages, prev + 1))}
                              className={currentPage === products.totalPages ? "pointer-events-none opacity-50" : ""}
                            />
                          </PaginationItem>
                        </PaginationContent>
                      </Pagination>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </section>
      
      <Features />
      <Newsletter />
      <Contact />
    </div>
  );
};

export default Home;
