import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/CartContext";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Star, ShoppingCart, ChevronLeft, Check, X } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const ProductDetail = () => {
  const { slug } = useParams();
  const [, navigate] = useLocation();
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);

  const { data: product, isLoading, error } = useQuery({
    queryKey: [`/api/products/${slug}`],
    queryFn: async () => {
      const response = await fetch(`/api/products/${slug}`);
      if (!response.ok) {
        throw new Error('Failed to fetch product');
      }
      return response.json();
    }
  });

  const handleQuantityChange = (value: number) => {
    if (value >= 1) {
      setQuantity(value);
    }
  };

  const handleAddToCart = () => {
    if (product) {
      addToCart({
        id: product.id,
        name: product.name,
        image: product.image,
        price: parseFloat(product.price),
        quantity
      });
      
      toast({
        title: "Produto adicionado",
        description: `${product.name} foi adicionado ao carrinho`,
        duration: 3000,
      });
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row gap-8">
          <Skeleton className="w-full md:w-1/2 h-[400px] rounded-lg" />
          <div className="w-full md:w-1/2">
            <Skeleton className="h-10 w-3/4 mb-4" />
            <Skeleton className="h-6 w-1/4 mb-4" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-3/4 mb-6" />
            <Skeleton className="h-10 w-full mb-4" />
            <Skeleton className="h-4 w-1/2 mb-4" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Produto não encontrado</h2>
        <p className="text-gray-600 mb-6">O produto que você está procurando não existe ou foi removido.</p>
        <Button onClick={() => navigate("/")}>Voltar para a loja</Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <Button 
        variant="ghost" 
        className="mb-6 flex items-center gap-2"
        onClick={() => navigate("/")}
      >
        <ChevronLeft size={16} />
        Voltar para a loja
      </Button>
      
      <div className="flex flex-col md:flex-row gap-8">
        {/* Product Image */}
        <div className="w-full md:w-1/2">
          <img 
            src={product.image} 
            alt={product.name} 
            className="w-full h-auto object-cover rounded-lg shadow-md"
          />
        </div>
        
        {/* Product Details */}
        <div className="w-full md:w-1/2">
          <div className="mb-6">
            {product.badge && (
              <Badge className="mb-2 bg-purple-600">{product.badge}</Badge>
            )}
            <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
            <div className="flex items-center mb-2">
              <div className="flex text-yellow-400 mr-2">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`h-4 w-4 ${i < Math.floor(parseFloat(product.rating.toString())) ? 'fill-current' : 'fill-none'}`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-500">({product.reviewCount} avaliações)</span>
            </div>
            <div className="text-2xl font-bold text-emerald-500 mb-4">
              {typeof product.price === 'string' 
                ? `R$${parseFloat(product.price).toFixed(2).replace('.', ',')}`
                : `R$${product.price.toFixed(2).replace('.', ',')}`}
            </div>
            <p className="text-gray-700 mb-6">{product.description}</p>
          </div>
          
          <div className="mb-6">
            <div className="flex items-center mb-4">
              <span className="mr-2 font-medium">Categoria:</span>
              <span>{product.category?.name || 'Não categorizado'}</span>
            </div>
            
            <div className="flex items-center mb-6">
              <span className={`flex items-center ${product.inStock ? 'text-emerald-500' : 'text-red-500'}`}>
                {product.inStock ? (
                  <>
                    <Check size={16} className="mr-1" />
                    Em estoque
                  </>
                ) : (
                  <>
                    <X size={16} className="mr-1" />
                    Esgotado
                  </>
                )}
              </span>
            </div>
          </div>
          
          <div className="mb-6">
            <div className="flex items-center mb-4">
              <span className="mr-4">Quantidade:</span>
              <div className="flex items-center">
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="h-8 w-8 rounded-full"
                  onClick={() => handleQuantityChange(quantity - 1)}
                  disabled={quantity <= 1}
                >
                  -
                </Button>
                <span className="mx-4">{quantity}</span>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="h-8 w-8 rounded-full"
                  onClick={() => handleQuantityChange(quantity + 1)}
                >
                  +
                </Button>
              </div>
            </div>
          </div>
          
          <Button 
            className="w-full bg-emerald-500 hover:bg-emerald-600 text-white"
            size="lg"
            onClick={handleAddToCart}
            disabled={!product.inStock}
          >
            <ShoppingCart className="mr-2 h-5 w-5" />
            Adicionar ao carrinho
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
