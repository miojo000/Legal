import { db } from "./index";
import * as schema from "@shared/schema";
import { eq } from "drizzle-orm";

async function seed() {
  try {
    console.log("🌱 Seeding database...");

    // Insert categories
    console.log("Seeding categories...");
    const categoryData = [
      { 
        name: "Descartáveis", 
        slug: "descartaveis", 
        description: "Vapes descartáveis com várias opções de sabores",
        icon: "fas fa-box",
        displayOrder: 1
      },
      { 
        name: "E-liquids", 
        slug: "e-liquids", 
        description: "Líquidos para recarga com diversos sabores",
        icon: "fas fa-tint",
        displayOrder: 2
      },
      { 
        name: "Pod Systems", 
        slug: "pod-systems", 
        description: "Sistemas de pod compactos e recarregáveis",
        icon: "fas fa-battery-full",
        displayOrder: 3
      },
      { 
        name: "Acessórios", 
        slug: "acessorios", 
        description: "Acessórios e peças para vapes",
        icon: "fas fa-cog",
        displayOrder: 4
      }
    ];

    // Check if categories already exist
    const existingCategories = await db.query.categories.findMany();
    
    if (existingCategories.length === 0) {
      for (const category of categoryData) {
        await db.insert(schema.categories).values(category);
      }
      console.log(`Inserted ${categoryData.length} categories`);
    } else {
      console.log(`Categories already exist, skipping...`);
    }

    // Get category IDs for product references
    const categories = await db.query.categories.findMany();
    const categoryMap = new Map(categories.map(c => [c.slug, c.id]));

    // Insert products
    console.log("Seeding products...");
    const productData = [
      {
        name: "Vape Pod 3000 Puffs",
        slug: "vape-pod-3000-puffs",
        description: "Descartável com sabor de morango ice",
        image: "https://storage.googleapis.com/replit/images/1746228226618_1eb6ef6d3a24afb36c90dd11c3e70e52.webp",
        price: "69.90",
        categoryId: categoryMap.get("descartaveis") || 1,
        inStock: true,
        featured: true,
        rating: "4.5",
        reviewCount: 42,
        badge: "Novo"
      },
      {
        name: "Pod System Vaporesso XRos",
        slug: "pod-system-recarregavel",
        description: "Sistema recarregável com 2 pods - prata e preto",
        image: "https://storage.googleapis.com/replit/images/1746228226631_0a43f9f1c56af0b9878cb1d2aa56a63d.jpg",
        price: "79.90",
        categoryId: categoryMap.get("pod-systems") || 3,
        inStock: true,
        featured: true,
        rating: "5.0",
        reviewCount: 67,
        badge: "Popular"
      },
      {
        name: "E-liquid Premium",
        slug: "e-liquid-premium",
        description: "Sabor menta refrescante - 30ml",
        image: "https://images.unsplash.com/photo-1603033156166-2ae22eb2b7e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        price: "54.90",
        categoryId: categoryMap.get("e-liquids") || 2,
        inStock: true,
        featured: false,
        rating: "4.0",
        reviewCount: 31
      },
      {
        name: "Kit de Bobinas",
        slug: "kit-de-bobinas",
        description: "Pack com 5 bobinas de reposição",
        image: "https://images.unsplash.com/photo-1626018961122-ab54950d0cf8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        price: "59.90",
        categoryId: categoryMap.get("acessorios") || 4,
        inStock: true,
        featured: false,
        rating: "4.0",
        reviewCount: 19
      },
      {
        name: "Vape Pen 1500 Puffs",
        slug: "vape-pen-1500-puffs",
        description: "Descartável sabor frutas vermelhas",
        image: "https://images.unsplash.com/photo-1555820445-f4f1ba40ba89?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        price: "64.90",
        categoryId: categoryMap.get("descartaveis") || 1,
        inStock: true,
        featured: false,
        rating: "3.5",
        reviewCount: 24,
        badge: "Promoção"
      },
      {
        name: "Carregador USB-C",
        slug: "carregador-usb-c",
        description: "Carregamento rápido para pod systems",
        image: "https://images.unsplash.com/photo-1557411732-1797a9171fcf?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        price: "49.90",
        categoryId: categoryMap.get("acessorios") || 4,
        inStock: false,
        featured: false,
        rating: "5.0",
        reviewCount: 54
      },
      {
        name: "Vape Ultra 5000 Puffs",
        slug: "vape-ultra-5000-puffs",
        description: "Descartável de longa duração com sabor de uva",
        image: "https://images.unsplash.com/photo-1560373052-084db4239c40?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        price: "79.90",
        categoryId: categoryMap.get("descartaveis") || 1,
        inStock: true,
        featured: true,
        rating: "4.8",
        reviewCount: 37,
        badge: "Novo"
      },
      {
        name: "E-liquid Tropical",
        slug: "e-liquid-tropical",
        description: "Sabor frutas tropicais - 30ml",
        image: "https://images.unsplash.com/photo-1595864728682-4cc9a14c2f8e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        price: "52.90",
        categoryId: categoryMap.get("e-liquids") || 2,
        inStock: true,
        featured: false,
        rating: "4.2",
        reviewCount: 28
      }
    ];

    // Delete existing products and insert new ones with updated images
    await db.delete(schema.products);
    console.log(`Deleted existing products`);
    
    for (const product of productData) {
      await db.insert(schema.products).values(product);
    }
    console.log(`Inserted ${productData.length} products`);

    console.log("✅ Seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
