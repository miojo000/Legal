import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { ordersInsertSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes prefix
  const apiPrefix = "/api";

  // Get all categories
  app.get(`${apiPrefix}/categories`, async (req, res) => {
    try {
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Get category by slug
  app.get(`${apiPrefix}/categories/:slug`, async (req, res) => {
    try {
      const { slug } = req.params;
      const category = await storage.getCategoryBySlug(slug);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      console.error("Error fetching category:", error);
      res.status(500).json({ message: "Failed to fetch category" });
    }
  });

  // Get all products with filters
  app.get(`${apiPrefix}/products`, async (req, res) => {
    try {
      const page = req.query.page ? parseInt(req.query.page as string) : 1;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 6;
      const maxPrice = req.query.maxPrice ? parseFloat(req.query.maxPrice as string) : undefined;
      const inStock = req.query.inStock === 'true';
      const search = req.query.search as string | undefined;
      
      // Handle category filter (can be array or string)
      let categorySlugs: string[] = [];
      const categories = req.query.categories;
      
      if (categories) {
        if (Array.isArray(categories)) {
          categorySlugs = categories as string[];
        } else {
          categorySlugs = [categories as string];
        }
      }
      
      const products = await storage.getAllProducts({
        page,
        limit,
        maxPrice,
        categorySlugs,
        inStock: inStock ? true : undefined,
        search
      });
      
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  // Get product by slug
  app.get(`${apiPrefix}/products/:slug`, async (req, res) => {
    try {
      const { slug } = req.params;
      const product = await storage.getProductBySlug(slug);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Create order (checkout)
  app.post(`${apiPrefix}/checkout`, async (req, res) => {
    try {
      // Validate order data
      const orderSchema = z.object({
        customerName: z.string().min(3, "Nome deve ter pelo menos 3 caracteres"),
        customerEmail: z.string().email("Email inválido"),
        customerPhone: z.string().min(10, "Telefone deve ter pelo menos 10 caracteres"),
        customerAddress: z.string().min(10, "Endereço deve ter pelo menos 10 caracteres"),
        items: z.array(z.object({
          productId: z.number(),
          quantity: z.number().min(1),
          price: z.number().min(0)
        })),
        total: z.number().min(0)
      });

      const validatedData = orderSchema.parse(req.body);
      
      // Create order
      const order = await storage.createOrder(validatedData);
      
      res.status(201).json(order);
    } catch (error) {
      console.error("Error creating order:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
