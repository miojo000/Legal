import { db } from "@db";
import { 
  products, 
  categories, 
  cartItems, 
  orders, 
  orderItems 
} from "@shared/schema";
import { 
  type Product, 
  type Category, 
  type CartItem,
  type Order,
  type OrderItem
} from "@shared/schema";
import { eq, and, gte, lte, desc, sql, count } from "drizzle-orm";

export const storage = {
  // Categories
  async getAllCategories(): Promise<Category[]> {
    return db.query.categories.findMany({
      orderBy: categories.displayOrder
    });
  },

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return db.query.categories.findFirst({
      where: eq(categories.slug, slug)
    });
  },

  // Products
  async getAllProducts(options: {
    page?: number;
    limit?: number;
    maxPrice?: number;
    categoryIds?: number[];
    categorySlugs?: string[];
    inStock?: boolean;
    search?: string;
  } = {}): Promise<{ items: Product[]; total: number; totalPages: number }> {
    const {
      page = 1,
      limit = 6,
      maxPrice,
      categoryIds,
      categorySlugs,
      inStock,
      search
    } = options;

    const offset = (page - 1) * limit;

    // Build dynamic filter conditions
    let filters = [];

    if (maxPrice) {
      filters.push(lte(products.price, maxPrice));
    }

    if (inStock) {
      filters.push(eq(products.inStock, true));
    }

    if (categoryIds && categoryIds.length > 0) {
      filters.push(sql`${products.categoryId} IN ${categoryIds}`);
    }

    if (categorySlugs && categorySlugs.length > 0) {
      // Get category ids from slugs
      const cats = await db.query.categories.findMany({
        where: sql`${categories.slug} IN ${categorySlugs}`,
        columns: { id: true }
      });
      const catIds = cats.map(c => c.id);
      
      if (catIds.length > 0) {
        filters.push(sql`${products.categoryId} IN ${catIds}`);
      }
    }

    if (search) {
      filters.push(
        sql`LOWER(${products.name}) LIKE LOWER(${'%' + search + '%'}) OR LOWER(${products.description}) LIKE LOWER(${'%' + search + '%'})`
      );
    }

    // Get total count for pagination
    const totalResult = await db
      .select({ count: count() })
      .from(products)
      .where(filters.length > 0 ? and(...filters) : undefined);

    const total = Number(totalResult[0]?.count || 0);
    const totalPages = Math.ceil(total / limit);

    // Get products with pagination
    const items = await db.query.products.findMany({
      where: filters.length > 0 ? and(...filters) : undefined,
      limit,
      offset,
      orderBy: [desc(products.featured), desc(products.createdAt)],
      with: {
        category: true
      }
    });

    return {
      items,
      total,
      totalPages
    };
  },

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return db.query.products.findFirst({
      where: eq(products.slug, slug),
      with: {
        category: true
      }
    });
  },

  async getProductById(id: number): Promise<Product | undefined> {
    return db.query.products.findFirst({
      where: eq(products.id, id),
      with: {
        category: true
      }
    });
  },

  // Cart
  async getCartItems(cartId: string): Promise<CartItem[]> {
    return db.query.cartItems.findMany({
      where: eq(cartItems.cartId, cartId),
      with: {
        product: true
      }
    });
  },

  async addToCart(
    cartId: string, 
    productId: number, 
    quantity: number
  ): Promise<CartItem> {
    // Check if item already exists in cart
    const existingItem = await db.query.cartItems.findFirst({
      where: and(
        eq(cartItems.cartId, cartId),
        eq(cartItems.productId, productId)
      )
    });

    if (existingItem) {
      // Update quantity if item exists
      const [updated] = await db
        .update(cartItems)
        .set({ quantity: existingItem.quantity + quantity })
        .where(eq(cartItems.id, existingItem.id))
        .returning();
      return updated;
    } else {
      // Add new item to cart
      const [newItem] = await db
        .insert(cartItems)
        .values({
          cartId,
          productId,
          quantity
        })
        .returning();
      return newItem;
    }
  },

  async updateCartItemQuantity(
    cartId: string,
    productId: number,
    quantity: number
  ): Promise<CartItem | undefined> {
    const [updated] = await db
      .update(cartItems)
      .set({ quantity })
      .where(
        and(
          eq(cartItems.cartId, cartId),
          eq(cartItems.productId, productId)
        )
      )
      .returning();
    return updated;
  },

  async removeFromCart(
    cartId: string,
    productId: number
  ): Promise<void> {
    await db
      .delete(cartItems)
      .where(
        and(
          eq(cartItems.cartId, cartId),
          eq(cartItems.productId, productId)
        )
      );
  },

  async clearCart(cartId: string): Promise<void> {
    await db
      .delete(cartItems)
      .where(eq(cartItems.cartId, cartId));
  },

  // Orders
  async createOrder(orderData: {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    customerAddress: string;
    total: number;
    items: { productId: number; quantity: number; price: number }[];
  }): Promise<Order> {
    const { items, ...orderInfo } = orderData;

    // Create order
    const [order] = await db
      .insert(orders)
      .values(orderInfo)
      .returning();

    // Create order items
    if (items.length > 0) {
      await db
        .insert(orderItems)
        .values(
          items.map((item) => ({
            orderId: order.id,
            productId: item.productId,
            quantity: item.quantity,
            price: item.price.toString()
          }))
        );
    }

    return order;
  },

  async getOrderById(id: number): Promise<Order | undefined> {
    return db.query.orders.findFirst({
      where: eq(orders.id, id),
      with: {
        items: {
          with: {
            product: true
          }
        }
      }
    });
  }
};
