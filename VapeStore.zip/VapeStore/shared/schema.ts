import { pgTable, text, serial, integer, boolean, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Define users table (keep existing)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Define categories table
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  icon: text("icon").notNull(),
  displayOrder: integer("display_order").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Define products table
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  image: text("image").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  categoryId: integer("category_id").references(() => categories.id).notNull(),
  inStock: boolean("in_stock").default(true).notNull(),
  featured: boolean("featured").default(false).notNull(),
  rating: decimal("rating", { precision: 3, scale: 1 }).default("4.0").notNull(),
  reviewCount: integer("review_count").default(0).notNull(),
  badge: text("badge"), // "New", "Popular", "Promotion", etc.
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Define cart items table
export const cartItems = pgTable("cart_items", {
  id: serial("id").primaryKey(),
  cartId: text("cart_id").notNull(), // session ID or user ID
  productId: integer("product_id").references(() => products.id).notNull(),
  quantity: integer("quantity").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Define orders table (for checkout)
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone").notNull(),
  customerAddress: text("customer_address").notNull(),
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
  status: text("status").default("pending").notNull(), // pending, processing, completed, cancelled
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Define order items table
export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").references(() => orders.id).notNull(),
  productId: integer("product_id").references(() => products.id).notNull(),
  quantity: integer("quantity").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
});

// Define table relations
export const categoriesRelations = relations(categories, ({ many }) => ({
  products: many(products)
}));

export const productsRelations = relations(products, ({ one }) => ({
  category: one(categories, { fields: [products.categoryId], references: [categories.id] })
}));

export const cartItemsRelations = relations(cartItems, ({ one }) => ({
  product: one(products, { fields: [cartItems.productId], references: [products.id] })
}));

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, { fields: [orderItems.orderId], references: [orders.id] }),
  product: one(products, { fields: [orderItems.productId], references: [products.id] })
}));

export const ordersRelations = relations(orders, ({ many }) => ({
  items: many(orderItems)
}));

// Schemas for validation
export const categoriesInsertSchema = createInsertSchema(categories, {
  name: (schema) => schema.min(2, "Nome deve ter pelo menos 2 caracteres"),
  description: (schema) => schema.optional(),
  icon: (schema) => schema.min(1, "Ícone é obrigatório")
});
export type CategoryInsert = z.infer<typeof categoriesInsertSchema>;
export type Category = typeof categories.$inferSelect;

export const productsInsertSchema = createInsertSchema(products, {
  name: (schema) => schema.min(3, "Nome deve ter pelo menos 3 caracteres"),
  description: (schema) => schema.min(5, "Descrição deve ter pelo menos 5 caracteres"),
  price: (schema) => schema.refine(val => parseFloat(val.toString()) >= 49.90 && parseFloat(val.toString()) <= 80.00, 
    "Preço deve estar entre R$49,90 e R$80,00"),
  badge: (schema) => schema.optional()
});
export type ProductInsert = z.infer<typeof productsInsertSchema>;
export type Product = typeof products.$inferSelect;

export const cartItemsInsertSchema = createInsertSchema(cartItems, {
  quantity: (schema) => schema.min(1, "Quantidade deve ser pelo menos 1")
});
export type CartItemInsert = z.infer<typeof cartItemsInsertSchema>;
export type CartItem = typeof cartItems.$inferSelect;

export const ordersInsertSchema = createInsertSchema(orders, {
  customerName: (schema) => schema.min(3, "Nome deve ter pelo menos 3 caracteres"),
  customerEmail: (schema) => schema.email("Email inválido"),
  customerPhone: (schema) => schema.min(10, "Telefone deve ter pelo menos 10 caracteres"),
  customerAddress: (schema) => schema.min(10, "Endereço deve ter pelo menos 10 caracteres")
});
export type OrderInsert = z.infer<typeof ordersInsertSchema>;
export type Order = typeof orders.$inferSelect;

export const orderItemsInsertSchema = createInsertSchema(orderItems, {
  quantity: (schema) => schema.min(1, "Quantidade deve ser pelo menos 1")
});
export type OrderItemInsert = z.infer<typeof orderItemsInsertSchema>;
export type OrderItem = typeof orderItems.$inferSelect;
